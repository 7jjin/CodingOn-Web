const Visitor = require('../model/Model');

exports.main = (req, res) => {
    res.render('index');
};
